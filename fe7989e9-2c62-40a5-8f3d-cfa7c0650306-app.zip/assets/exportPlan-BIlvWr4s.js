import{o as e}from"./msal-DSHe7Tlj.js";var t=[`Inicial`,`Primaria`,`Secundaria`],n=[`A`,`B`,`C`,`D`],r=[`Competencia Ética y Ciudadana`,`Competencia Comunicativa`,`Competencia Pensamiento Lógico, Creativo y Crítico`,`Competencia Resolución de Problemas`,`Competencia Científica y Tecnológica`,`Competencia Ambiental y de la Salud`,`Competencia Desarrollo Personal y Espiritual`],i=[`Educación para la salud`,`Educación ambiental y desarrollo sostenible`,`Educación en valores y derechos humanos`,`Educación para la convivencia y la paz`,`Género y equidad`,`Tecnología, información y comunicación`,`Cultura dominicana e identidad nacional`],a=[`diagnóstica`,`formativa`,`sumativa`],o=e=>(e??[]).join(`
`),s=e=>(e??``).split(`
`).map(e=>e.trim()).filter(Boolean),c=e=>(e??``).replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`).replace(/\n/g,`<br/>`),l=e=>e?.length?`<ul>${e.map(e=>`<li>${c(e)}</li>`).join(``)}</ul>`:`<p>—</p>`,u=(e,t)=>`<h2>${c(e)}</h2>${t}`,d=(e,t)=>`<tr><th>${c(e)}</th><td>${c(t)}</td></tr>`;async function f(){try{let e=await fetch(`/images/logo-arca.jpg`);if(!e.ok)return``;let t=await e.blob();return await new Promise(e=>{let n=new FileReader;n.onload=()=>e(n.result),n.onerror=()=>e(``),n.readAsDataURL(t)})}catch{return``}}function p(t){return t?`<div class="hdr">
    <img class="logo" src="${t}" alt="Escudo Arca de Cristo"/>
    <div>
      <div class="school">${c(e.shortName)}</div>
      <div class="sub">${c(e.institution)} · ${c(e.city)}</div>
    </div>
  </div>`:``}var m=`<style>
  body{font-family:'Segoe UI',Arial,sans-serif;color:#1B2430;max-width:860px;margin:24px auto;padding:0 20px;line-height:1.55}
  .hdr{display:flex;align-items:center;gap:14px;border-bottom:3px solid #0082AD;padding-bottom:10px;margin-bottom:14px}
  .hdr .logo{width:60px;height:60px;object-fit:contain;border-radius:8px}
  .hdr .school{font-weight:800;color:#0A1F2B;font-size:20px;letter-spacing:-0.01em}
  .hdr .sub{color:#667085;font-size:12px}
  h1{color:#0A1F2B;border-bottom:3px solid #0082AD;padding-bottom:8px;margin-bottom:4px;font-size:22px}
  h2{color:#0082AD;font-size:14px;margin:16px 0 6px;border-left:4px solid #E62327;padding-left:8px;text-transform:uppercase;letter-spacing:.02em}
  .kicker{color:#0082AD;font-weight:800;font-size:12px;letter-spacing:.14em;text-transform:uppercase;margin-bottom:2px}
  .title{color:#0A1F2B;font-weight:800;font-size:20px;margin:0 0 2px}
  .meta{color:#667085;font-size:12.5px;margin-bottom:10px}
  table{width:100%;border-collapse:collapse;margin:10px 0}
  td,th{border:1px solid #E2E8F0;padding:6px 10px;text-align:left;font-size:12.5px;vertical-align:top}
  th{background:#0A1F2B;color:#fff}
  ul{margin:4px 0 0 18px;padding:0}
  .act{border:1px solid #E2E8F0;border-radius:10px;padding:12px 14px;margin-bottom:10px;break-inside:avoid}
  .act .n{color:#0082AD;font-weight:800;font-size:12px;text-transform:uppercase;letter-spacing:.08em}
  .act .t{font-weight:700;font-size:14px}
  .orient{background:#F3F8FB;border-radius:8px;padding:8px 10px;color:#0B2E3F;font-size:12.5px;margin:8px 0}
  .recuerda{border:1px solid #F0D9A8;background:#FFF9ED;border-radius:10px;padding:12px 14px}
  .situacion{border-left:4px solid #E62327;padding:4px 0 4px 14px;color:#0B2E3F}
  .marca{font-size:11px;color:#667085;text-align:center;margin-top:24px;border-top:1px solid #E2E8F0;padding-top:8px}
</style>`;function h(t,n,r,i){let a=t.secuenciasCurriculares?.length?t.secuenciasCurriculares.map(e=>c(`${e.area} ${e.codigo?`SC ${e.codigo}`:``}`).trim()).join(` · `):n,o=t.secuenciasCurriculares?.length?`<table><tr><th>Área</th><th>Código</th><th>Título</th></tr>${t.secuenciasCurriculares.map(e=>`<tr><td>${c(e.area)}</td><td>${c(e.codigo)}</td><td>${c(e.titulo)}</td></tr>`).join(``)}</table>`:``,s=t.actividadesDetalle?.length?t.actividadesDetalle.map((e,t)=>`
      <div class="act">
        <div class="n">Actividad ${t+1} · ${e.fase}</div>
        <div class="t">${c(e.titulo||e.fase)}</div>
        <div>${c(e.descripcion)}</div>
        ${e.orientaciones?`<div class="orient"><b>Orientaciones para la o el docente:</b> ${c(e.orientaciones)}</div>`:``}
        ${e.duracion?`<div style="margin-top:4px"><b>Duración:</b> ${c(e.duracion)}</div>`:``}
        ${l(e.estrategias)}
      </div>`).join(``):`<table>
        <tr><th>Inicio</th><td>${c(t.actividades.inicio)}</td></tr>
        <tr><th>Desarrollo</th><td>${c(t.actividades.desarrollo)}</td></tr>
        <tr><th>Cierre</th><td>${c(t.actividades.cierre)}</td></tr>
      </table>`,f=t.apoyos?.length?`<table><tr><th>Si observas…</th><th>Trata de…</th></tr>${t.apoyos.map(e=>`<tr><td>${c(e.observacion)}</td><td>${c(e.tratamiento)}</td></tr>`).join(``)}</table>`:``,h=t.anexos?.length?t.anexos.map((e,t)=>`<div class="act"><div class="n">Anexo ${t+1}</div><div class="t">${c(e.titulo)}</div><div>${c(e.contenido)}</div></div>`).join(``):``;return`<!doctype html><html lang="es"><head><meta charset="utf-8"/><title>Unidad de Aprendizaje · ${c(t.tema)}</title>${m}</head><body>
${p(i)}
<div class="kicker">Propuesta didáctica: Unidad de Aprendizaje</div>
<div class="title">UA · ${c(t.tema)}</div>
<p class="meta">${c(r)} ${c(t.section||``)} · ${c(a)} · ${c(e.institution)}</p>
<table>
${d(`Nivel`,t.nivel)}
${d(`Grado`,`${r} ${t.section||``}`)}
${d(`Área(s)`,a)}
${d(`Temporalización`,t.duracion)}
${d(`Fecha`,t.fecha)}
</table>
${o?u(`Secuencias curriculares correspondientes`,o):``}
${t.recuerda?u(`Recuerda`,`<div class="recuerda">${c(t.recuerda)}</div>`):``}
${t.situacionAprendizaje?u(`Situación de Aprendizaje`,`<div class="situacion">${c(t.situacionAprendizaje)}</div>`):``}
${u(`Competencias fundamentales`,l(t.competenciasFundamentales))}
${u(`Competencias específicas · Contenidos · Indicadores de logro · Materiales`,`<table>
<tr><th>Competencias específicas</th><th>Contenidos</th><th>Indicadores de logro</th><th>Materiales</th></tr>
<tr>
  <td>${l(t.competenciasEspecificas)}</td>
  <td><b>Conceptuales:</b><br>${c(t.contenidos.conceptuales)}<br><br><b>Procedimentales:</b><br>${c(t.contenidos.procedimentales)}<br><br><b>Actitudinales:</b><br>${c(t.contenidos.actitudinales)}</td>
  <td>${l(t.indicadoresLogro)}</td>
  <td>${l(t.materiales??t.recursos)}</td>
</tr></table>`)}
${u(`Estrategias y técnicas de enseñanza y aprendizaje`,l(t.estrategias))}
${t.recursosDigitales?.length?u(`Recursos didácticos digitales`,l(t.recursosDigitales)):``}
${u(`Secuencia didáctica`,s)}
${f?u(`Si observas…, trata de…`,f):``}
${h?u(`Anexos`,h):``}
${u(`Evaluación`,`Tipo: ${c(t.evaluacion.tipo)} · Instrumento: ${c(t.evaluacion.instrumento)}<br/>${c(t.evaluacion.criterios)}`)}
<p class="marca">Generado por la Intranet ${c(e.shortName)} · ${new Date().toLocaleDateString(`es-DO`)}</p>
</body></html>`}function g(t,n,r,i){return`<!doctype html><html lang="es"><head><meta charset="utf-8"/><title>Planificación ${c(t.tema)}</title>${m}</head><body>
${p(i)}
<div class="kicker">Planificación de clase</div>
<div class="title">${c(t.tema)}</div>
<p class="meta">${c(r)} ${c(t.section||``)} · ${c(n)} · ${c(e.institution)}</p>
<table>${d(`Nivel`,t.nivel)}${d(`Fecha`,t.fecha)}${d(`Duración`,t.duracion)}</table>
${t.recuerda?u(`Recuerda`,`<div class="recuerda">${c(t.recuerda)}</div>`):``}
${u(`Competencias fundamentales`,l(t.competenciasFundamentales))}
${u(`Competencias específicas`,l(t.competenciasEspecificas))}
${u(`Contenidos`,`<table><tr><th>Conceptuales</th><td>${c(t.contenidos.conceptuales)}</td></tr><tr><th>Procedimentales</th><td>${c(t.contenidos.procedimentales)}</td></tr><tr><th>Actitudinales</th><td>${c(t.contenidos.actitudinales)}</td></tr></table>`)}
${u(`Actividades`,`<table><tr><th>Inicio</th><td>${c(t.actividades.inicio)}</td></tr><tr><th>Desarrollo</th><td>${c(t.actividades.desarrollo)}</td></tr><tr><th>Cierre</th><td>${c(t.actividades.cierre)}</td></tr></table>`)}
${u(`Estrategias`,l(t.estrategias))}
${u(`Recursos`,l(t.recursos))}
${u(`Indicadores de logro`,l(t.indicadoresLogro))}
${u(`Evaluación`,`Tipo: ${c(t.evaluacion.tipo)} · Instrumento: ${c(t.evaluacion.instrumento)}<br/>${c(t.evaluacion.criterios)}`)}
<p class="marca">Generado por la Intranet ${c(e.shortName)} · ${new Date().toLocaleDateString(`es-DO`)}</p>
</body></html>`}function _(e,t,n,r){return e.tipo===`unidad`?h(e,t,n,r):g(e,t,n,r)}async function v(e,t,n){let r=_(e,t,n,await f()),i=new Blob([`﻿`,r],{type:`application/msword;charset=utf-8`}),a=URL.createObjectURL(i),o=document.createElement(`a`);o.href=a,o.download=`Planificacion_${e.tema.replace(/[^\wáéíóúñÁÉÍÓÚÑ]+/g,`_`).slice(0,40)}.doc`,document.body.appendChild(o),o.click(),document.body.removeChild(o),URL.revokeObjectURL(a)}async function y(e,t,n){let r=_(e,t,n,await f()),i=window.open(``,`_blank`,`noopener,width=900,height=700`);i&&(i.document.open(),i.document.write(r),i.document.close(),i.onload=()=>{i.focus(),i.print()})}export{t as a,o as c,i,s as l,y as n,n as o,r,a as s,v as t};